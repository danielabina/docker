package com.projeto.candidato.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;








import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.projeto.candidato.models.Candidato;
import com.projeto.candidato.repository.CandidatoRepository;


@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200")
public class CandidatoController {
	
	@Autowired
	private CandidatoRepository er;
	
	
//listar
	
	@GetMapping("/candidatos")
	public List<Candidato> getAllCandidatos() {
	    return er.findAll();
	}
	//listar por id
	@GetMapping("/candidato/{Id}")
	public Candidato getCandidatoById(@PathVariable(value ="Id") Long Id){

		return er.findOne(Id);
	}
	//atualizar por id
	@PutMapping("/candidato/{Id}")
	public Candidato updateCandidato(@PathVariable(value = "Id") Long Id,
	                                        @Valid @RequestBody Candidato candidatoDetails) {

		Candidato candidato = er.findOne(Id);

		candidato.setNome(candidatoDetails.getNome());
		candidato.setData_nascimento(candidatoDetails.getData_nascimento());
		candidato.setEmail(candidatoDetails.getEmail());
		candidato.setEndereço(candidatoDetails.getEndereco());
		candidato.setTelefone(candidatoDetails.getTelefone());
	    

		Candidato updatedcandidato = er.save(candidato);
	    return updatedcandidato;
	}
	
//cadastrar
	
	@PostMapping
	public Candidato cadastracandidato(@RequestBody @Valid Candidato candidato){
		er.save(candidato);
		
		return candidato;
	}
	
//deletar
	

	
	@DeleteMapping("/candidato/{Id}")
	public void deleteCandidato(@PathVariable(value = "Id") long Id) {
		er.delete(Id);
	}
	


}
