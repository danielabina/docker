const proxy = [
    {
    context:'/api',
    target:'http://spring-docker:8086',
    pathRewrite: {'^/api':''}
    }
]