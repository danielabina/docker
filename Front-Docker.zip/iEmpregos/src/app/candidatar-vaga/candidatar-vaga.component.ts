import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidatar-vaga',
  templateUrl: './candidatar-vaga.component.html',
  styleUrls: ['./candidatar-vaga.component.css']
})
export class CandidatarVagaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
