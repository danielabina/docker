export class Candidato {
    id: number;
    nome: string;
    endereco : string;
    data_nascimento:string;
    telefone: string;
    email: string;
    cpf: string;
    senha: string;
}