export class CandidatoVaga {
    id: number;
    idVaga: number;
    idCandidato: number;
    dataInscricao: string;
    //nomeVaga: string;
    nome: number;
}