import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './op-cad.component.html',
  styleUrls: ['./op-cad.component.css']
})
export class OpcadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
